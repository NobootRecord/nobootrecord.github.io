 ___       ____________
|   \     |  ________  |		---===  Ivan Movchan  ===---
| |\ \    | |        | |		also known as   NobootRecord
| | \ \   | |________| |		---===   presents...  ===---
| |  \ \  |  ___  _____|
| |   \ \ | |   \ \				...:::    KamstRec    :::...
| |    \ \| |    \ \___         Version 1.0     (2022-04-21)
|_|     \___|     \____|    

<<<<<<<<<<<<<<<<<<<<<<<<	[	Some Information	]

KamstRec (Keyboard And Mouse State Recorder)
Tiny Win32 utility that records system keyboard and mouse state.
It writes data to system console, but it also can write data to text files.

KamstRec is written in pure C x86 and is no more than 64 kilobytes in size,
that's why it is so fast and nice :)

Usage in terminal:
No special command-line arguments required by program.
If you need help, you can run KamstRec with absolutely random stuff in command-line argument (example: kamstrec loremipsum).
If need to write data into special text file, you can run KamstRec
by this command: kamstrec > yourFile.txt (hard disk overload warning!)
To exit program, just press CTRL + Q keys.

<<<<<<<<<<<<<<<<<<<<<<<<	[	System Requirements	]

Operating system:			Windows XP and later

Hardware:					Keyboard, mouse
							and user brains =)

<<<<<<<<<<<<<<<<<<<<<<<<	[	Program History		]

2021

The first version of KamstRec was released.
Program was written just for fun,
but later it has been transformed into useful (I hope)
system utility.

2022

In April 2022 I decided to publish KamstRec to my website,
so I re-wrote some parts of KamstRec source code
and added new features (help, system clock, etc.).

#	Version 1.0	(2022-04-21)
	The first public version of KamstRec.

<<<<<<<<<<<<<<<<<<<<<<<<	[	Contact Me			]

VKontakte:		[https://vk.com/NobootRecord]
GitHub:			[https://github.com/NobootRecord]
YouTube:		[https://youtube.com/c/NobootRecord]
Web:			[https://nobootrecord.github.io]

<<<<<<<<<<<<<<<<<<<<<<<<	[	The End				]

Recorded at 18:41 21.04.2022