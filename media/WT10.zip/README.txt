...::: Ivan Movchan, also known as NobootRecord :::...
	   presents you...
	   
	          ---=== WiSSTracker 1.0 ===---
	   
	  ------------------------------------------
	
	Name: Windows System Sounds Tracker / WiSSTracker
	Type: Multimedia / Sound Editor
	Version: 1.0
	Release Date: 2022-05-03
	OS: Windows 9x and later
	
	  ------------------------------------------
	  
	Windows System Sounds Tracker (or simply WiSSTracker)
    is a program that allows you making "music"
    from Windows system sounds. It has simple and nice GUI
    (FT2-like), supports working with files
    and also it is not so hard to use it :)
	
	Here is some WiSSTracker syntax notes:
	
	A = asterisk sound
	D = default sound
	E = exclamation sound
	X = exit sound
	H = hand sound
	Q = question sound
	S = start sound
	W = welcome sound
	
	# = some comments
	$ = some milliseconds delay
	
    Example song can be found at dms2253.txt file.
	
	  ------------------------------------------
	  
	==> Version 1.0 (2022-05-03)
	[*] The first public release of the program.
	
	  ------------------------------------------
	  
	E-Mail:  [johnmovechan at yandex dot ru]
	         [gogol2k7 at gmail dot com]
	Website: [https://nobootrecord.github.io]
	
	  ------------------------------------------
	  
	Copyright/Pasteleft (c) Ivan Movchan, 2022.
	13:41 03.05.2022