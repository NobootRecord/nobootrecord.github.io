#include <stdio.h>
#include <stdlib.h>
main(int argc,char*argv[]){for(int i=atoi(argv[1]);i<atoi(argv[2])+1;i++){int p=0;if(i>1){for(int j=1;j<i;j++){p=!(i%j==0&&j>1&&j<i);if(!p)break;};};if(p)printf("%d\n",i);};}