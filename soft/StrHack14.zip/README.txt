...::: Ivan Movchan, also known as NobootRecord :::...
	   presents you...
	   
	   ---===     String Hacker v1.4     ===---
	   
	  ------------------------------------------
	
	Name: String Hacker / StrHack
	Type: Text Editor / Utility
	Version: 1.4
	Release Date: 2022-04-26
	OS: Windows XP+
	    with .NET Framework 2.0 installed
	
	  ------------------------------------------
	  
	String Hacker (or simply StrHack) 
	is tiny and user-friendly program that
	modifies (or "hacks") string/text data
	using operations and algorithms.
	
	* Simple and nice GUI
	* English and Russian localizations
	  are built-in
	* Works with text files also
	* No more than 1MB in size
	
	  ------------------------------------------

	==> Version 1.4 (2022-04-26)
	[*] New fresh and nice GUI
	[+] Added new operations and algorithms
	[-] Fixed bugs with magical value
	  
	==> Version 1.3 (2022-03-19)
	[*] Program is rewritten from scratch
	[-] Fixed some minor bugs
	  
	==> Version 1.2 (2022-02-08)
	[*] New program icon
	[-] Fixed bug with endless messageboxes.
	    Thanks to Jenka Zvereva for noticed bug!
		[https://vk.com/jenkazvereva]
	  
	==> Version 1.1 (2022-01-08)
	[*] New program icon, nothing special...
	  
	==> Version 1.0 (2022-01-03)
	[*] The first public version of program
	
	  ------------------------------------------
	  
	E-Mail:  [johnmovechan at yandex dot ru]
	         [gogol2k7 at gmail dot com]
	Website: [https://nobootrecord.github.io]
	
	  ------------------------------------------
	  
	  Copyright/Pasteleft (c) Ivan Movchan, 2022.
	  20:05 26.04.2022