String Hacker
=============

Version 1.1.0.0
Copyright (c) Ivan Movchan.
https://nobootrecord.github.io

-------------

What is this?

A small but useful (I hope) program that XORes, ANDes, ORes and NOTes text & strings.
It can be used for encrypting files (no criminal!) and when playing with BOOL operations :)

Features:

•  It is small (~480kb)

•  It has simple and user-friendly interface

•  It works with text files

•  It supports locale files (in archive you can find English and Russian locale files!)

•  It does not need too powerful computer to go - it is compatible even with Windows 95!

-------------

Archive contents:

StrHack.exe		String Hacker executable file
LOCALE_RU.txt		Russian locale file
LOCALE_EN.txt		English locale file
README_EN.txt		English README file you are reading now
README_RU.txt		The same README but in Russian
MyWebsite.url		URL to my website

-------------

Do you want to contact me?

VKontakte:	https://vk.com/NobootRecord
Discord: 	NobootRecord#2297
YouTube:	https://tinyurl.com/NobootRecordYT
My own website hosted on GitHub:	https://nobootrecord.github.io

-------------

Enjoy using my software! Have a nice day!

Best wishes,
	Ivan Movchan aka NobootRecord
		08.01.2022