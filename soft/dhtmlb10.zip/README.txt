Dumpster HTML Builder version 1.0.0.0 [01302022]
by Ivan Movchan aka NobootRecord (c) 2022.

A small program that generates dumpster HTML files with random contents, random tags, random symbols, random colors, etc.
Written just for fun.

Небольшая программа, которая генерирует мусорные и не несущие никакой смысловой нагрузки HTML-файлы. Написана чисто по приколу.

https://nobootrecord.github.io