 ___       ____________
|   \     |  ________  |		---===     Ivan Movchan     ===---
| |\ \    | |        | |		  also known as     NobootRecord  
| | \ \   | |________| |		---===      presents...     ===---
| |  \ \  |  ___  _____|
| |   \ \ | |   \ \				...::: Turbo RAM Downloader :::...
| |    \ \| |    \ \___         Version 1.0           (2022-04-18)
|_|     \___|     \____|    

<<<<<<<<<<<<<<<<<<<<<<<<	[	Some Information	]

Turbo RAM Downloader (or simply TRAMD) is small but very useful
program for downloading RAM from Internet. It has simple, nice
and user-friendly user interface, works fast...
...and it is also free and open-source!!!

<<<<<<<<<<<<<<<<<<<<<<<<	[	System Requirements	]

Operating system:			Windows XP and later

Hardware:					Keyboard, mouse
							and user brains =)

<<<<<<<<<<<<<<<<<<<<<<<<	[	Program History		]

If talking seriously, I have developed this program just for fun.
Turbo RAM Downloader was inspired by "download ram" memes
and "Download more RAM" (https://www.downloadmoreram.com/) website.
I wrote this piece of bullsh1t with Borland Delphi 7.0 in about 10 minutes,
so that's why it is so poor and low-quality :)

#	CURRENT: Version 1.0	(2022-04-18)
	The first public version of Turbo RAM Downloader.

<<<<<<<<<<<<<<<<<<<<<<<<	[	Contact Me			]

VKontakte:		[https://vk.com/NobootRecord]
GitHub:			[https://github.com/NobootRecord]
YouTube:		[https://youtube.com/c/NobootRecord]
Web:			[https://nobootrecord.github.io]

<<<<<<<<<<<<<<<<<<<<<<<<	[	The End				]

Recorded at 18:46 19.04.2022