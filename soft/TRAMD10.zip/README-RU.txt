 ___       ____________
|   \     |  ________  |		---===       Иван Мовчан       ===---
| |\ \    | |        | |		также известный как      NobootRecord  
| | \ \   | |________| |		---===     представляет...     ===---
| |  \ \  |  ___  _____|
| |   \ \ | |   \ \			 ...:::  Turbo RAM Downloader (TRAMD) :::...
| |    \ \| |    \ \___           Версия 1.0           (2022-04-18)
|_|     \___|     \____|    

<<<<<<<<<<<<<<<<<<<<<<<<	[	Краткая Информация	]

Turbo RAM Downloader (or simply TRAMD) is small but very useful
program for downloading RAM from Internet. It has simple, nice
and user-friendly user interface, works fast...
...and it is also free and open-source!!!

Turbo RAM Downloader (или же просто TRAMD) - это маленькая,
но очень полезная утилита для загрузки и скачивания
оперативной памяти (ОЗУ) из сети Интернет.
Она имеет простой и понятный интерфейс, быстро работает...
...а ещё она бесплатная и открытая!!!

<<<<<<<<<<<<<<<<<<<<<<<<	[	Системные Требования	]

Операционная система:		Windows XP и новее

Железо:						Клавиатура, мышь
							и, конечно же, мозги =)

<<<<<<<<<<<<<<<<<<<<<<<<	[	История Программы		]

Если серьёзно, я разработал эту программу чисто ради прикола.
Turbo RAM Downloader был вдохновлён мемами "скачать оперативную память"
и сайтом "Download more RAM" (https://www.downloadmoreram.com/).
Я написал эту хрень (по-другому никак не могу сказать, если без мата)
на Borland Delphi 7.0 за ~10 минут, поэтому она такая убогая :)

#	ТЕКУЩАЯ: Версия 1.0	(2022-04-18)
	Самая первая публичная версия Turbo RAM Downloader.

<<<<<<<<<<<<<<<<<<<<<<<<	[	Контакты			]

ВКонтакте:		[https://vk.com/NobootRecord]
GitHub:			[https://github.com/NobootRecord]
YouTube:		[https://youtube.com/c/NobootRecord]
Вебсайт:			[https://nobootrecord.github.io]

<<<<<<<<<<<<<<<<<<<<<<<<	[	Конец				]

Записано в 18:47 17.04.2022