String Hacker
-------------

This is a small utility that can hack (modify, corrupt, etc.)
your strings and text using binary operations like XOR, AND, OR and others. It has simple and user-friendly GUI (with English and Russian localizations!). It can work with text files. It is lightweight.
It is written just for fun :D

Небольшая программа, которая позволяет производить бинарные операции (XOR, OR, AND, NOT) над текстом и строками.<br>Написана чисто ради прикола. Может пригодиться для развлечений с текстом и бинарными операциями, а также для шифрования файлов (в мирных целях, разумеется) :D

Made with love for you by: Ivan Movchan (Иван Мовчан)

Copyright (c) 2022.
https://nobootrecord.github.io